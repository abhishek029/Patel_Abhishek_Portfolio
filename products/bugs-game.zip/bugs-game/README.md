# BUG-GAME

This is a click game where you have to kill bugs by clicking on them and you have time countdown going on top to end the game.
