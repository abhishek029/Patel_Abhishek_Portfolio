# Purevolume.com redesign

A two page site redesign of Purevolume.com. The article redesigned for style.

## Built With

* [Foundation](https://foundation.zurb.com/) - The web framework used
* [JQuery](https://jquery.com/) - The web framework used


## Development Team

* **Ahbi Patel** - *Developer* 
* **Jinkal Patel** - *Developer*
* **Jordan Priestman** - *Motion Designer* 
* **Blake Hause** - *Graphic Designer* 
* **David Estanol** - *Project Manager* 


**Link to Repo 
https://github.com/destanol/bootcamp
